<?php

namespace App\Http\Livewire;

use Livewire\Component;

class DatosComplementariosVictima extends Component
{
    public function render()
    {
        return view('livewire.vistas.datos-complementarios-victima');
    }
}
