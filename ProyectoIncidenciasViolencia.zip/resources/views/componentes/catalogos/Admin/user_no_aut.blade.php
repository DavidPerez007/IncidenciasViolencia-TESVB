@extends('layouts.appuser')
@section('contenido')

    <!-- Button trigger modal -->

    <div class="container">
         <div class="card">
                <div class="card-body">
                    <div class="text-center">  <H1>Usuario registrado correctamente, el administrador revisará la información y aprobará o negará su solicitud.</H1></div>

                </div>

        </div>

    </div>

@endsection
