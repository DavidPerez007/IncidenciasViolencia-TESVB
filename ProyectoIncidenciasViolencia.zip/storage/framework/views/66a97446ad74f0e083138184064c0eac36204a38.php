<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" crossorigin="anonymous">
    <div class="row justify-content-center ">
        <div class="col-4">
            <div class="card ">
                <div class="card-header alert alert-primary text-center font-weight-bold  bg-dark">
                  Registrarse
                </div>
                <div class="card-body ">

        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>

            <div class="">
                
                <input id="name" class="form-control" placeholder="Nombre" type="text" name="name" :value="old('name')" required autofocus autocomplete="name" />
            </div>
            <div class="mt-4">
                
                <input id="email" placeholder="Correo electrónico"  class="form-control" type="email" name="email" :value="old('email')" required >
            </div>

            <div class="mt-4">
                
                <div class="input-group">
                    <input  id="txtPassword"  placeholder="Contraseña" class="form-control" type="password" name="password" required autocomplete="new-password" />
                  <div class="input-group-append">
                    <button id="show_password" class="btn btn-primary" type="button" onclick="mostrarPassword()"> <span class="fa fa-eye-slash icon"></span> </button>
                  </div>
            </div>
            </div>
         <div class="mt-4">
                
            <div class="input-group-append">
                <input id="password_confirmation" placeholder="Confirmar contraseña" class="form-control" type="password" name="password_confirmation" required autocomplete="new-password" />
            </div>
            </div>
            <div class="mt-2 p-2">
                <button class="btn btn-primary btn-sm btn-block font-weight-bold rounded-pill">
                    <?php echo e(__('Registrarse')); ?>

                </button>
            </div>
            <div class="d-flex justify-content-center links">
                <a class="font-weight-bold" href="<?php echo e(route('login')); ?>">
                    <?php echo e(__('¿Ya tiene una cuenta?')); ?>

                </a>
            </div>

        </form>

    </div>
</div>
</div>
</div>
<!-- Para el ver/ocultar caracteres de contrasena-->
<script type="text/javascript">
    function mostrarPassword(){
            var cambio = document.getElementById("txtPassword");
            if(cambio.type == "password"){
                cambio.type = "text";
                $('.icon').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
            }else{
                cambio.type = "password";
                $('.icon').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
            }
        };

    </script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\IncidenciasViolencia\resources\views/auth/register.blade.php ENDPATH**/ ?>