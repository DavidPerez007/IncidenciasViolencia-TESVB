<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" crossorigin="anonymous">
    <script type="text/javascript">
        function mostrarPassword(){
                var cambio = document.getElementById("password");
                if(cambio.type == "password"){
                    cambio.type = "text";
                    $('.icon').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
                }else{
                    cambio.type = "password";
                    $('.icon').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
                }
            }

            $(document).ready(function () {
            //CheckBox mostrar contraseña
            $('#ShowPassword').click(function () {
                $('#Password').attr('type', $(this).is(':checked') ? 'text' : 'password');
            });
        });
        </script>

        <?php if(session('status')): ?>
            <div class="mb-4 font-medium text-sm text-green-600">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
            <div class="row justify-content-center">
                <div class="col-4">
                    <div class="card">
                        <div class="card-header alert alert-primary text-center font-weight-bold bg-dark">
                           Iniciar sesión
                        </div>
                        <div class="card-body">

                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="">
                            
                            <input id="email" class="form-control" type="email" name="email" :value="old('email')" required autofocus placeholder="Correo electrónico">
                        </div>
                        <div class="mt-4">
                            
                            <div class="input-group">
                            <input id="password" class="form-control" type="password" name="password" required autocomplete="current-password" placeholder="Contraseña">
                            <div class="input-group-append">
                                <button id="show_password" class="btn btn-primary" type="button" onclick="mostrarPassword()"> <span class="fa fa-eye-slash icon"></span> </button>
                              </div>
                        </div>
                        </div>

                        <div class="form-check mt-2">
                            <input type="checkbox"  class="form-check-input" id="remember_me" name="remember" />
                            <label for="remember_me" class="form-check-label">
                                <span><?php echo e(__('Recordar contraseña')); ?></span>
                            </label>
                        </div>
                        <div class="mt-1 p-2">
                            <button class="btn btn-primary btn-sm btn-block font-weight-bold rounded-pill"> <?php echo e(__('Entrar')); ?>  </button>
                        </div>
                        <div class="d-flex justify-content-center links mb-2">
                            ¿No tiene una cuenta? <a class="font-weight-bold" href="<?php echo e(route('register')); ?>" class="ml-2">&nbsp;Registrarse</a>
                        </div>
                        <div class="d-flex justify-content-center links">
                        <?php if(Route::has('password.request')): ?>
                            <a class="font-weight-bold" href="<?php echo e(route('password.request')); ?>">
                              ¿Olvidó su contraseña?
                            </a>
                        <?php endif; ?>
                        </div>



                    </form>
                        </div>
                    </div>
                </div>
            </div>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\IncidenciasViolencia\resources\views/auth/login.blade.php ENDPATH**/ ?>