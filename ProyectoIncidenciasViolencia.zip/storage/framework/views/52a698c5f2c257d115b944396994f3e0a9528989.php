<!-- This is a template to show all victim cases from each state -->
<script src="https://cdn.tailwindcss.com"></script>

<?php if(!empty($victims_registers)): ?>
    <div class="overflow-x-auto max-h-96">
        <table class="min-w-full bg-white border border-pink-200">
            <thead>
                <tr class="bg-pink-200 text-gray-600 uppercase text-sm">
                    <th class="py-3 px-6 text-left">Municipio</th>
                    <th class="py-3 px-6 text-left">Estado</th>
                    <th class="py-3 px-6 text-left">Vive con</th>
                </tr>
            </thead>
            <tbody class="text-gray-600 text-sm font-light">
                <?php $__currentLoopData = $victims_registers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $register): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b border-gray-200 hover:bg-gray-100">
                        <td class="py-3 px-6 text-left"><?php echo e($register->municipio); ?></td>
                        <td class="py-3 px-6 text-left"><?php echo e($register->estado); ?></td>
                        <td class="py-3 px-6 text-left"><?php echo e($register->vive_con); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <p class="text-gray-600 text-center mt-4">No se encontraron incidencias para este estado.</p>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\IncidenciasViolencia\resources\views/template/incidentTable.blade.php ENDPATH**/ ?>